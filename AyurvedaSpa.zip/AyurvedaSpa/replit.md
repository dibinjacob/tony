# AyurCure Wellness Website

## Overview
A fully static, mobile-first one-page website for an Ayurvedic wellness spa. Built with pure HTML5 and inline CSS, featuring a premium dark/golden spa-inspired design with no backend dependencies.

## Brand
- **Name**: AyurCure Wellness
- **Tagline**: "Ancient Ayurvedic Healing for modern, stressful lives."
- **Approach**: Authentic Kerala Ayurvedic treatments delivered in a calm, luxurious spa environment

## Project Structure
```
.
├── index.html          # Single HTML file with inline CSS
├── images/             # Ayurvedic spa images
│   ├── hero-ayurveda.jpg
│   ├── about-ayurveda-massage.jpg
│   ├── gallery-room.jpg
│   ├── gallery-herbs.jpg
│   ├── gallery-massage.jpg
│   └── gallery-kizhi.jpg
└── replit.md          # Project documentation
```

## Features
- **Hero Section**: Dark gradient background with golden accents, compelling tagline, and floating signature retreat card
- **About Section**: Explanation of Ayurvedic philosophy with Kerala-trained therapist badge
- **Treatments Section**: 3 signature therapies (Panchakarma, Shirodhara, Kizhi) with tags and chips
- **Packages Section**: 3 curated wellness packages with pricing (₹2,999, ₹7,499, ₹14,999)
- **Gallery Section**: Visual showcase of therapy rooms, herbs, and treatments
- **Contact Section**: Static demo form and contact information
- **Premium Design**: Dark theme with warm golden/copper/bronze gradients
- **Mobile-First**: Fully responsive layout optimized for all devices
- **Smooth Navigation**: Sticky header with smooth scroll to sections

## Design System
### Color Palette
- Dark Background: `#1a1410` (primary)
- Darker Background: `#0f0c08`
- Warm Dark: `#2a1f1a`
- Gold: `#d4af37` (accent)
- Gold Light: `#f0d78c`
- Copper: `#b87333`
- Bronze: `#cd7f32`
- Cream: `#f5efe6` (text)

### Typography
- Headings: Playfair Display (serif, elegant)
- Body: Nunito (clean sans-serif)

### Design Elements
- Rounded corners: 20-25px
- Soft shadows and glows
- Gradient borders
- Hover animations and transforms

## Technology Stack
- HTML5
- CSS3 (inline, with Grid & Flexbox)
- Google Fonts (Playfair Display, Nunito)

## Sections
1. **Hero**: Two-column layout with hero image, floating card, and CTA buttons
2. **About**: Grid layout explaining Ayurvedic approach with image badge
3. **Treatments**: 3-column grid of signature therapies with tags and chips
4. **Packages**: 3 pricing tiers with features and CTAs
5. **Gallery**: Main image + 3-item grid showcasing spa facilities
6. **Contact**: Static form + contact information blocks
7. **Footer**: Copyright and navigation links

## Recent Changes
- 2024-11-16: Complete redesign with AyurCure Wellness branding
- Implemented dark/golden premium theme
- Added all sections with authentic Ayurvedic stock images
- Single HTML file with inline CSS for easy deployment
- Mobile-responsive layout with premium animations
